getwd()
setwd("/Users/nandulee/Documents/SLIIT Y2S1/PS/week07/Lab_06/")
getwd()

###Exercise
##Question 01
#part 01
#Here, random variable X has binomial distribution with n = 50 and p = 0.85

#part 02
1 - pbinom(47, 50, 0.85, lower.tail = FALSE)

##Question 02
#part 01
#Random variable X = number of calls received in one hour

#part 02
#Here, random variable x has poisson distribution with lambda = 12

#part 03
dpois(15, 12)